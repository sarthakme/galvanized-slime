CREATE TABLE products (
	id SERIAL PRIMARY KEY,
	name VARCHAR(50),
	price real,
	url VARCHAR(200),
	description VARCHAR(50)
);